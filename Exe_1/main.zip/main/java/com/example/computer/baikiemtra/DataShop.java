package com.example.computer.baikiemtra;

public class DataShop {
    private int ImgPicture;
    private String Name;

    public DataShop(int img, String name){
        ImgPicture = img;
        Name = name;
    }
    public int getImgPicture() {
        return ImgPicture;
    }

    public void setImgPicture(int imgPicture) {
        ImgPicture = imgPicture;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
