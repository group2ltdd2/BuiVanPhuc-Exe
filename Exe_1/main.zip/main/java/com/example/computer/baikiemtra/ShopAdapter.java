package com.example.computer.baikiemtra;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.computer.baikiemtra.R.layout.item_row;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.viewHolder> {
    ArrayList<DataShop> dataShops;
    Context context;

    public ShopAdapter(ArrayList<DataShop> dataShops, Context context){
        this.dataShops = dataShops;
        this.context = context;
    }
    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from( parent.getContext() );
        View itemView = layoutInflater.inflate( R.layout.item_row,parent,false );
        return new viewHolder (itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int i) {
        holder.txtName.setText( dataShops.get( i ).getName() );
        holder.imgPicture.setImageResource( dataShops.get( i ).getImgPicture() );
    }

    @Override
    public int getItemCount() {
        return dataShops.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder{
        TextView txtName;
        ImageView imgPicture;
        public viewHolder(@NonNull View itemView) {
            super( itemView );
            txtName = (TextView) itemView.findViewById( R.id.txtName );
            imgPicture = (ImageView) itemView.findViewById( R.id.imgPicture );
        }
    }
}
