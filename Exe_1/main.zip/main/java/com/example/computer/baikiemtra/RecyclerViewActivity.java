package com.example.computer.baikiemtra;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class RecyclerViewActivity extends AppCompatActivity {
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.layout_recycler_view );
        initView();

        Button btnNext = (Button) findViewById( R.id.btnNext );
        btnNext.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(RecyclerViewActivity.this, Activity.class);
               intent.setFlags(intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        } );
    }
    public void initView(){
        RecyclerView recyclerView = (RecyclerView)findViewById( R.id.recycler_view );
        recyclerView.setHasFixedSize( true );
        LinearLayoutManager layoutManager = new LinearLayoutManager( this,LinearLayoutManager.VERTICAL,false );
        recyclerView.setLayoutManager( layoutManager );
        ArrayList<DataShop> arrayList = new ArrayList<>( );
        arrayList.add( new DataShop( R.drawable.ex,"Exciter" ) );
        arrayList.add( new DataShop( R.drawable.winner,"Winner" ) );
        arrayList.add( new DataShop( R.drawable.sonic,"Sonic" ) );
        arrayList.add( new DataShop( R.drawable.satria,"Satria" ) );
        arrayList.add( new DataShop( R.drawable.nvx,"NVX" ) );
        arrayList.add( new DataShop( R.drawable.vario,"Vario" ) );
        ShopAdapter shopAdapter = new ShopAdapter(arrayList, getApplicationContext());
        recyclerView.setAdapter( shopAdapter );
    }
}
