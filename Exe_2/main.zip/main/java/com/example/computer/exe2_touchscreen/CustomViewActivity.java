package com.example.computer.exe2_touchscreen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.example.computer.exe2_touchscreen.View.CustomView;

import java.util.jar.Attributes;

public class CustomViewActivity extends AppCompatActivity {
    private CustomView mCustomView;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.layout_custom_view );
        setTitle( "Custom View" );
        Button btnPrev = (Button) findViewById( R.id.btnPrev);
        mCustomView = (CustomView) findViewById(R.id.customView);

        findViewById(R.id.btn_swap_color).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCustomView.swapColor();
            }
        });

        btnPrev.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(CustomViewActivity.this, TouchPaintActivity.class);
                intent.setFlags(intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        } );
    }


}
